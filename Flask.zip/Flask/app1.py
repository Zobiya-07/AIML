from __future__ import annotations

import os
import pickle
from typing import Dict, Any, List

from flask import Flask, render_template, request, redirect, url_for, flash
import numpy as np


app = Flask(__name__)
app.secret_key = "replace-with-a-secure-random-secret"


def _resolve_model_path() -> str:
    here = os.path.dirname(os.path.abspath(__file__))
    return os.path.join(here, "model.pkl")


def _load_model():
    model_path = _resolve_model_path()
    if not os.path.exists(model_path):
        return None, model_path
    with open(model_path, "rb") as f:
        model = pickle.load(f)
    return model, model_path


model, model_path = _load_model()


def _bool_from_yes_no(value: str) -> int:
    return 1 if str(value).strip().lower() in {"yes", "y", "true", "1"} else 0


def _num_from_range(text: str, plus_default: float) -> float:
    cleaned = str(text).replace(" ", "")
    if "+" in cleaned:
        return float(plus_default)
    if "-" in cleaned:
        parts = cleaned.split("-")
        try:
            left = float(parts[0])
            right = float(parts[1])
            return (left + right) / 2.0
        except Exception:
            return float(plus_default)
    try:
        return float(cleaned)
    except Exception:
        return float(plus_default)


def preprocess_input(form_data: Dict[str, Any]) -> np.ndarray:
    gender_map = {"male": 1, "female": 0}
    severity_map = {"mild": 0, "moderate": 1, "severe": 2}
    diag_map = {"<1year": 0, "1-5years": 1, ">5years": 2}

    gender_val = gender_map.get(str(form_data.get("Gender", "")).strip().lower(), 0)
    age_val = _num_from_range(form_data.get("Age", "18-34"), 26)
    history_val = _bool_from_yes_no(form_data.get("History", "No"))
    patient_val = _bool_from_yes_no(form_data.get("Patient", "No"))
    take_med_val = _bool_from_yes_no(form_data.get("TakeMedication", "No"))
    severity_val = severity_map.get(str(form_data.get("Severity", "mild")).strip().lower(), 0)
    breath_val = _bool_from_yes_no(form_data.get("BreathShortness", "No"))
    visual_val = _bool_from_yes_no(form_data.get("VisualChanges", "No"))
    nose_val = _bool_from_yes_no(form_data.get("NoseBleeding", "No"))

    diag_key = str(form_data.get("Whendiagnoused", "<1 Year")).replace(" ", "").lower()
    diag_key = diag_key.replace("years", "year")
    if diag_key == "1-5year":
        diag_key = "1-5years"
    diag_val = diag_map.get(diag_key, 0)

    systolic_val = _num_from_range(form_data.get("Systolic", "111 - 120"), 135)
    diastolic_val = _num_from_range(form_data.get("Diastolic", "81 - 90"), 105)
    diet_val = _bool_from_yes_no(form_data.get("ControlledDiet", "No"))

    feature_vector: List[float] = [
        gender_val,
        age_val,
        history_val,
        patient_val,
        take_med_val,
        severity_val,
        breath_val,
        visual_val,
        nose_val,
        diag_val,
        systolic_val,
        diastolic_val,
        diet_val,
    ]

    x = np.array(feature_vector, dtype=float).reshape(1, -1)

    if hasattr(model, "n_features_in_"):
        needed = int(model.n_features_in_)
        current = x.shape[1]
        if current > needed:
            x = x[:, :needed]
        elif current < needed:
            pad = np.zeros((1, needed - current), dtype=float)
            x = np.hstack([x, pad])
    return x


@app.route("/")
def index():
    if model is None:
        flash(f"Model file not found at: {model_path}. Place model.pkl in the Flask folder.")
    return render_template("index.html")


@app.route("/details")
def details():
    return render_template("details.html")


@app.route("/predict", methods=["POST"])
def predict():
    if model is None:
        flash("Model not available. Please add model.pkl and reload.")
        return redirect(url_for("index"))

    user_input = {k: v for k, v in request.form.items()}
    x = preprocess_input(user_input)
    try:
        y_pred = model.predict(x)
    except Exception as exc:
        flash(f"Prediction failed: {exc}")
        return redirect(url_for("predict"))

    pred_value = y_pred[0] if isinstance(y_pred, (list, np.ndarray)) else y_pred
    return render_template("result.html", prediction=str(pred_value))


if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    app.run(host="0.0.0.0", port=port, debug=True)

